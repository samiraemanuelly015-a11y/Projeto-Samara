import Model.Voluntario;
import Model.Acao;
import Model.Plantio;
import Model.MutiraoReciclagem;
import Model.OficinaEcologica;

import Exceptions.EmailDuplicadoException;
import Exceptions.AcaoLotadaException;
import Exceptions.InscricaoDuplicadaException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Comparator;

public class Impacta {

    private HashMap<String, Voluntario> voluntarios;
    private HashMap<Integer, Acao> acoes;
    private int proximoId;

    public Impacta() {
        voluntarios = new HashMap<>();
        acoes = new HashMap<>();
        proximoId = 1;
    }

    public boolean cadastrarVoluntario(String nome, String email, String matricula) {

        String emailFormatado = email.trim().toLowerCase();

        if (voluntarios.containsKey(emailFormatado)) {
            throw new EmailDuplicadoException("E-mail já cadastrado!");
        }

        Voluntario voluntario = new Voluntario(nome, emailFormatado, matricula);

        voluntarios.put(emailFormatado, voluntario);

        return true;
    }

    public String exibirVoluntario(String email) {

        Voluntario voluntario = voluntarios.get(email.trim().toLowerCase());

        if (voluntario == null) {
            return "Voluntário não encontrado!";
        }

        return voluntario.exibirDetalhes();
    }

    public String[] listarVoluntarios() {

        ArrayList<Voluntario> lista = new ArrayList<>(voluntarios.values());

        lista.sort(
                Comparator.comparingInt(Voluntario::getPontuacao)
                        .reversed()
                        .thenComparing(Voluntario::getNome)
        );

        String[] resultado = new String[lista.size()];

        for (int i = 0; i < lista.size(); i++) {
            resultado[i] = lista.get(i).exibirDetalhes();
        }

        return resultado;
    }

    public int cadastrarPlantio(String titulo, String descricao, String data,
                                int maxParticipantes, int qtdMudas) {

        int id = proximoId++;

        Plantio plantio = new Plantio(
                id, titulo, descricao,
                converterData(data),
                maxParticipantes, qtdMudas
        );

        acoes.put(id, plantio);

        return id;
    }

    public int cadastrarMutirao(String titulo, String descricao, String data,
                                int maxParticipantes, int duracaoHoras) {

        int id = proximoId++;

        MutiraoReciclagem mutirao = new MutiraoReciclagem(
                id, titulo, descricao,
                converterData(data),
                maxParticipantes, duracaoHoras
        );

        acoes.put(id, mutirao);

        return id;
    }

    public int cadastrarOficina(String titulo, String descricao, String data,
                                int maxParticipantes, int duracaoHoras,
                                boolean kitMaterial) {

        int id = proximoId++;

        OficinaEcologica oficina = new OficinaEcologica(
                id, titulo, descricao,
                converterData(data),
                maxParticipantes, duracaoHoras, kitMaterial
        );

        acoes.put(id, oficina);

        return id;
    }

    public boolean inscreverVoluntario(String emailVoluntario, int idAcao) {

        String emailFormatado = emailVoluntario.trim().toLowerCase();

        Voluntario voluntario = voluntarios.get(emailFormatado);
        Acao acao = acoes.get(idAcao);

        if (voluntario == null || acao == null) {
            return false;
        }

        for (Voluntario participante : acao.getVoluntarios()) {

            if (participante.getEmail().equalsIgnoreCase(emailVoluntario.trim())) {
                throw new InscricaoDuplicadaException("Voluntário já inscrito nesta ação!");
            }
        }

        if (acao.estaLotada()) {
            throw new AcaoLotadaException("Ação com capacidade máxima atingida!");
        }

        acao.adicionarVoluntario(voluntario);

        voluntario.adicionarAcao(acao.calcularPontuacao());

        return true;
    }

    public String exibirDetalhesAcao(int idAcao) {

        Acao acao = acoes.get(idAcao);

        if (acao == null) {
            return "Ação não encontrada!";
        }

        String detalhes = "ID: " + acao.getId() +
                "\nTítulo: " + acao.getTitulo() +
                "\nDescrição: " + acao.getDescricao() +
                "\nData: " + acao.getData() +
                "\nPontuação: " + acao.calcularPontuacao() +
                "\nVoluntários inscritos: ";

        if (acao.getVoluntarios().isEmpty()) {
            detalhes += "\nNenhum voluntário inscrito.";
        } else {

            for (Voluntario voluntario : acao.getVoluntarios()) {
                detalhes += "\n- " + voluntario.getNome();
            }
        }

        if (acao instanceof Plantio) {
            Plantio plantio = (Plantio) acao;
            detalhes += "\nQuantidade de mudas: " + plantio.getQtdMudas();

        } else if (acao instanceof MutiraoReciclagem) {
            MutiraoReciclagem mutirao = (MutiraoReciclagem) acao;
            detalhes += "\nDuração em horas: " + mutirao.getDuracaoHoras();

        } else if (acao instanceof OficinaEcologica) {
            OficinaEcologica oficina = (OficinaEcologica) acao;
            detalhes += "\nDuração em horas: " + oficina.getDuracaoHoras();
            detalhes += "\nOferece kit educativo: " + oficina.isKitMaterial();
        }

        return detalhes;
    }

    private LocalDateTime converterData(String data) {
        return LocalDate.parse(
                data,
                DateTimeFormatter.ofPattern("dd/MM/yyyy")
        ).atStartOfDay();
    }
}
