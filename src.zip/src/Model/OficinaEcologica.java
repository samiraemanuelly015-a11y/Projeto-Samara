package Model;

import java.time.LocalDateTime;

public class OficinaEcologica extends Acao {

    private int duracaoHoras;
    private boolean kitMaterial;

    public OficinaEcologica(int id, String titulo, String descricao,
                            LocalDateTime data, int maxParticipantes,
                            int duracaoHoras, boolean kitMaterial) {

        super(id, titulo, descricao, data, maxParticipantes);
        this.duracaoHoras = duracaoHoras;
        this.kitMaterial = kitMaterial;
    }

    public int getDuracaoHoras() {
        return duracaoHoras;
    }

    public boolean isKitMaterial() {
        return kitMaterial;
    }

    @Override
    public int calcularPontuacao() {
        int pontos = 3 * duracaoHoras;

        if (kitMaterial) {
            pontos += 10;
        }

        return pontos;
    }
}