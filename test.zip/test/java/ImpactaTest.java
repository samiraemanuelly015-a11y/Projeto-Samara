import Model.Plantio;
import Model.MutiraoReciclagem;
import Model.OficinaEcologica;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ImpactaTest {

    @Test
    public void testarPontuacaoPlantio() {

        Plantio plantio = new Plantio(
                1,
                "Plantio de Árvores",
                "Plantio no condomínio",
                LocalDateTime.now(),
                20,
                20
        );

        assertEquals(45, plantio.calcularPontuacao());
    }

    @Test
    public void testarPontuacaoMutirao() {

        MutiraoReciclagem mutirao = new MutiraoReciclagem(
                2,
                "Mutirão de Reciclagem",
                "Coleta de materiais recicláveis",
                LocalDateTime.now(),
                15,
                5
        );

        assertEquals(20, mutirao.calcularPontuacao());
    }

    @Test
    public void testarPontuacaoOficina() {

        OficinaEcologica oficina = new OficinaEcologica(
                3,
                "Oficina Ecológica",
                "Educação ambiental",
                LocalDateTime.now(),
                10,
                4,
                true
        );

        assertEquals(22, oficina.calcularPontuacao());
    }

    @Test
    public void testarRankingVoluntarios() {

        Impacta sistema = new Impacta();

        sistema.cadastrarVoluntario("Julianny", "juliannyfarias@gmail.com", "001");
        sistema.cadastrarVoluntario("Karoline Queiroz", "karolinequeiroz@gmail.com", "002");
        sistema.cadastrarVoluntario("Samira Alves", "samiraalves@gmail.com", "003");

        int idPlantio = sistema.cadastrarPlantio(
                "Plantio",
                "Plantio de mudas",
                "10/11/2026",
                20,
                20
        );

        int idMutirao = sistema.cadastrarMutirao(
                "Mutirão",
                "Reciclagem",
                "11/11/2026",
                20,
                5
        );

        sistema.inscreverVoluntario("juliannyfarias@gmail.com", idPlantio);
        sistema.inscreverVoluntario("karolinequeiroz@gmail.com", idPlantio);
        sistema.inscreverVoluntario("samiraalves@gmail.com", idMutirao);

        String[] ranking = sistema.listarVoluntarios();

        assertTrue(ranking[0].contains("Julianny"));
        assertTrue(ranking[1].contains("Karoline Queiroz"));
        assertTrue(ranking[2].contains("Samira Alves"));
    }
}
